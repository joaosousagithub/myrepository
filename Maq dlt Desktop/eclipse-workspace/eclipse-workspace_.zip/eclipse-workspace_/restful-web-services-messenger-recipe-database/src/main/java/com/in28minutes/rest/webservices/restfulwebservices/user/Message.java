package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "message")
public class Message {
	
	@Id
	private int id;
	
	//@Size(min=2, message="Message should have at least two characters")
	private String descricao;
	
	//@Past(message = "Birthday shoud be in the past") //mas era LocalDate
	//private Date created;
	
	private String author;
	

	@OneToMany(mappedBy = "mensagem", cascade = CascadeType.ALL)//este cascade = CascadeType.ALL não está no tut
	//@JsonIgnore
	private List<Comment> comments;
	
	public Message() {
		
	}
	
	public Message(int id, String author, String descricao) {
		super();
		this.id = id;
		this.descricao = descricao;
		//this.created = new Date();
		this.author = author;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/*public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}*/
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public List<Comment> getComments() {
		return comments;
	}
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	public Comment getComment(int idComment) {
		int retorno = -1;
		for(int i=0;i<comments.size();i++) {
			if(comments.get(i).getId() == idComment) {
				retorno = i;
				break;
			}
		}
		return comments.get(retorno);
	}
	/*public void addComment(Comment comment) {
		comments.add(comment);
	}
	public void removeComment(int idComment) {
		for(int i=0;i<comments.size();i++) {
			if(comments.get(i).getId() == idComment) {
				comments.remove(i);
				break;
			}
		}
	}*/
	@Override
	public String toString() {
		return "User [id=" + id + ", descricao=" + descricao + ", author=" + author + "]";
	}
	
	
}
