package com.in28minutes.rest.webservices.restfulwebservices.jpa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.in28minutes.rest.webservices.restfulwebservices.user.Message;

/*public interface MessageRepository extends JpaRepository<Message, Integer> {

}*/

public interface MessageRepository extends JpaRepository<Message, Integer> {

	//Page<Message> findByPublished(boolean published, Pageable pageable);
	//Page<Message> findByDescricaoContaining(String descricao, Pageable pageable);
	
	List<Message> findByDescricao(String descricao);
}
