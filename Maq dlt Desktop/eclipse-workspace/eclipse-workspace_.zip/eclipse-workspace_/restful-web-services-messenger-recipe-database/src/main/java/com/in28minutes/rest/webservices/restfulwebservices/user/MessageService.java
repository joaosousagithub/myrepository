package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class MessageService {

	private static List<Message> messages = new ArrayList<>();
	
	private static int messagesCount = 10;
	
	static {
		messages.add(new Message(++messagesCount, "msg1", "author1"));
		messages.add(new Message(++messagesCount, "msg2", "author1"));
		messages.add(new Message(++messagesCount, "msg3", "author2"));
		messages.add(new Message(++messagesCount, "msg4", "author3"));
		messages.add(new Message(++messagesCount, "msg5", "author4"));
		
		/*List<Comment> lstComments = new ArrayList<>();
		lstComments.add(new Comment(1, "um comment", "auth1"));
		lstComments.add(new Comment(2, "um comment_b", "auth2"));
		messages.get(0).setComments(lstComments);
		
		List<Comment> lstComments2 = new ArrayList<>();
		lstComments2.add(new Comment(1, "um comment 2", "auth3"));
		messages.get(1).setComments(lstComments2);*/
	}
	
	public List<Message> getAll(){
		return messages;
	}
	
	public Message getMessageById(int id) {
		Predicate<? super Message> predicate = message -> (message.getId() == id)/*message.getId().equals(id)*/;//return messages.stream().filter(predicate).findFirst().get();
		return messages.stream().filter(predicate).findFirst().orElse(null);
	}
	
	public List<Comment> getAllComments(int id){
		Message m = getMessageById(id);
		return null;// m.getComments();		
	}
	
	public Comment getMessageCommentById(int id, int idComment) {
		Message m = getMessageById(id);
		return null;// m.getComment(idComment);
	}
	
	public Message save(Message message) {
		message.setId(++messagesCount);
		messages.add(message);
		return message;
	}
	public Comment saveComment(int id, Comment comment) {
		Message m = getMessageById(id);
//		m.addComment(comment);
		return comment;
	}
		
	public void deleteById(int id) {
		Predicate<? super Message> predicate = message -> message.getId() == id/*message.getId().equals(id)*/;
		messages.removeIf(predicate);
	}
	public void deleteCommentById(int id, int idComment) {
		Message m = getMessageById(id);
//		m.removeComment(idComment);
	}
	
	public List<Message> getAllMessagesForName(String name){
		List<Message> messageForName = new ArrayList<>();
		for(Message message : messages) {
			if(message.getDescricao().compareTo(name) == 0) {
				messageForName.add(message);
			}
			//if(year == message.getId())
			//	messageForYear.add(message);
		}
		return messageForName;
	}
	public List<Message> getAllMessagesPaginated(int start, int size){
		List<Message> list = new ArrayList<Message>(messages);
		if(start + size > list.size()) return new ArrayList<Message>();
		return list.subList(start, start + size);
	}
}