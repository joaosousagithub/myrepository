package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.net.URI;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.in28minutes.rest.webservices.restfulwebservices.exception.UserNotFoundException;
import com.in28minutes.rest.webservices.restfulwebservices.paginationfiltering.MessageFilterBean;

import jakarta.validation.Valid;

@RestController
public class MessageResource {
	
	private MessageService service = new MessageService();
	
	@GetMapping("/messages")
	public List<Message> getAllMessagesFilterAndPagination(MessageFilterBean filterBean){
		if(filterBean.getName() != null) {			
			return service.getAllMessagesForName(filterBean.getName());
		}
		if(filterBean.getStart() >= 0 && filterBean.getSize() > 0) {
			return service.getAllMessagesPaginated(filterBean.getStart(), filterBean.getSize());
		}
		return service.getAll();
	}
	
	/*@GetMapping("/messages")
	public List<Message> getAllMessages(){
		return service.getAll();
	}*/
	
	@GetMapping("/messages/{id}")
	public Message getMessage(@PathVariable int id) {
		//return service.getMessageById(id);
		
		Message message = service.getMessageById(id);
		
		if(message == null) 
			throw new UserNotFoundException("id:"+id);
		
		return message;						
	}
	
	@GetMapping("/messages/{id}/comments")
	public List<Comment> getMessageComments(@PathVariable int id){
		return service.getAllComments(id);
				
	}
	
	@GetMapping("/messages/{id}/comments/{idComment}")
	public Comment getMessageComment(@PathVariable int id, @PathVariable int idComment){
		return service.getMessageCommentById(id, idComment);
				
	}
	
	@PostMapping("/messages")
	//public void createMessage(@RequestBody Message message){
	public ResponseEntity<Object> createUser(@Valid @RequestBody Message message){
		Message savedMessage = service.save(message);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest()
						.path("/{id}")
						.buildAndExpand(savedMessage.getId())
						.toUri();
		return ResponseEntity.created(location).build();
		//service.save(message);			
	}
	@PostMapping("/messages/{id}/comments")
	public ResponseEntity<Object> createComment(@PathVariable int id, @Valid @RequestBody Comment comment){
		Comment savedComment = service.saveComment(id, comment);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest()
						.path("/{idComment}")
						.buildAndExpand(savedComment.getId())
						.toUri();
		return ResponseEntity.created(location).build();
		//service.saveComment(id, comment);
	}
	
	@DeleteMapping("/messages/{id}")
	public void deleteMessage(@PathVariable int id){
		service.deleteById(id);
	}
	@DeleteMapping("/messages/{id}/comments/{idComment}")
	public void deletePost(@PathVariable int id, @PathVariable int idComment){
		service.deleteCommentById(id, idComment);
	}
	
	//PUT, UPDATE, PATCH ???
}