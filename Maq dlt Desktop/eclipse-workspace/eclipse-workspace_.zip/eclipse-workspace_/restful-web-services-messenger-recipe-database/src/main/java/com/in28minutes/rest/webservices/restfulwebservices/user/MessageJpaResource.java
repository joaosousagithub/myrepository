package com.in28minutes.rest.webservices.restfulwebservices.user;

//import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
//import org.springframework.hateoas.EntityModel;
//import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.in28minutes.rest.webservices.restfulwebservices.exception.UserNotFoundException;

import com.in28minutes.rest.webservices.restfulwebservices.jpa.CommentRepository;
import com.in28minutes.rest.webservices.restfulwebservices.jpa.MessageRepository;
import com.in28minutes.rest.webservices.restfulwebservices.paginationfiltering.MessageFilterBean;

import jakarta.validation.Valid;

@RestController
public class MessageJpaResource {
	
	private MessageRepository messageRepository;
	
	private CommentRepository commentRepository;
	
	public MessageJpaResource(MessageRepository messageRepository, CommentRepository commentRepository) {
		this.messageRepository = messageRepository;
		this.commentRepository = commentRepository;
	}
	
	@GetMapping("/jpa/messages")
	public List<Message> retrieveAllMessages(MessageFilterBean filterBean){
		if(filterBean.getName() != null) {
			/*List<Message> messageForName = new ArrayList<>();
			for(Message message : messageRepository.findAll()) {
				if(message.getDescricao().compareTo(filterBean.getName()) == 0)
					messageForName.add(message);
			}
			return messageForName;*/
			return messageRepository.findByDescricao(filterBean.getName());
		}
		if(filterBean.getStart() >= 0 && filterBean.getSize() > 0) {
			/*List<Message> list = new ArrayList<Message>(messageRepository.findAll());
			if(filterBean.getStart() + filterBean.getSize() > list.size()) return new ArrayList<Message>();
				return list.subList(filterBean.getStart(), filterBean.getStart() + filterBean.getSize());*/
			
			List<Message> messages = new ArrayList<>();
			Pageable pagingSort = PageRequest.of(filterBean.getStart(), filterBean.getSize());
			Page<Message> pageMessages = messageRepository.findAll(pagingSort);
			
			messages = pageMessages.getContent();
			
			return messages;
		}
		return messageRepository.findAll();																
	}
	
	
	
	@GetMapping("/jpa/messages/{id}")
	public Message/*EntityModel<User>*/ retrieveMessage(@PathVariable int id){
		
		/*Optional<User> user = userRepository.findById(id);
		
		if(user.isEmpty()) 
			throw new UserNotFoundException("id:"+id);
		
		EntityModel<User> entityModel = EntityModel.of(user.get());
		
		WebMvcLinkBuilder link = linkTo(methodOn(this.getClass()).retrieveAllUsers());
		entityModel.add(link.withRel("all-users"));
		
		return entityModel;*/
		Message message = messageRepository.findById(id).get();
		
		//if(message == null) 
		//	throw new UserNotFoundException("id:"+id);
		
		return message;	
	}
	
	@GetMapping("/jpa/messages/{id}/comments")
	public List<Comment/*Post*/> retrievePostsForMessages(@PathVariable int id){
		//Optional<User> user = userRepository.findById(id);
		Message m = messageRepository.findById(id).get();
		
		//if(user.isEmpty()) throw new UserNotFoundException("id:"+id);
		
		//return user.get().getPosts();
		return m.getComments();
	}
	@GetMapping("/jpa/messages/{id}/comments/{commentId}")
	public /*List<Post>*/ /*String*/ /*Post*/Comment retrieveCommentForMessage(@PathVariable int id, @PathVariable int commentId){
		
	/*	Optional<User> user = userRepository.findById(id);
		
		if(user.isEmpty()) 
			throw new UserNotFoundException("id:"+id);
		
		//return user.get().getPosts();
		return user.get().getPost(postId);*/
		Message m = messageRepository.findById(id).get();
		return m.getComment(commentId);
	}
	
	@PostMapping("/jpa/messages")
	public ResponseEntity<Object> createUser(@Valid @RequestBody Message message){
		Message savedMessage = messageRepository.save(message);
		URI location = ServletUriComponentsBuilder.fromCurrentRequest()
						.path("/{id}")
						.buildAndExpand(savedMessage.getId())
						.toUri();
		return ResponseEntity.created(location).build();
	}
	
	
	@PostMapping("/jpa/messages/{id}/comments")
	public ResponseEntity<Object> createPostsForUser(@PathVariable int id, @Valid @RequestBody Comment comment){
		//Optional<Message> user = userRepository.findById(id);
		Message message = messageRepository.findById(id).get();
		
		//if(user.isEmpty()) throw new UserNotFoundException("id:"+id);
		
		comment.setMensagem(message);
		
		Comment savedComment = commentRepository.save(comment);
		
		URI location = ServletUriComponentsBuilder.fromCurrentRequest()
				.path("/{id}")
				.buildAndExpand(savedComment.getId())
				.toUri();
		return ResponseEntity.created(location).build();
	}
	
	@DeleteMapping("/jpa/messages/{id}")
	public void deleteUser(@PathVariable int id){
		//Message user = userRepository.findById(id).get();
		messageRepository.deleteById(id);
	}
	
	@DeleteMapping("/jpa/messages/{id}/comments/{idComment}")
	public void deleteComment(@PathVariable int id, @PathVariable int idComment){
		//userRepository.deleteById(id);
		commentRepository.deleteById(idComment);
	}
}