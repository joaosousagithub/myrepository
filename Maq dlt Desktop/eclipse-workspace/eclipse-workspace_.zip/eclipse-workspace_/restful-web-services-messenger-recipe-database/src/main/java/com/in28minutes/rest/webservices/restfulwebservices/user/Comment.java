package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
//import jakarta.validation.constraints.Past;
//import jakarta.validation.constraints.Size;
import jakarta.persistence.Table;

@Entity
@Table(name = "comment")
public class Comment {
	
	@Id
	private int id; 
	
	//@Size(min=2, message="Comment should have at least two characters")
	private String descricao;
	
	//private Date created;
	private String author;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	private Message mensagem;
	
	public Comment() {
		
	}
	
	public Comment(int id, String author, String descricao) {
		super();
		this.id = id;
		this.descricao = descricao;
		//this.created = new Date();
		this.author = author;
	}
	
	public Message getMensagem() {
		return mensagem;
	}

	public void setMensagem(Message mensagem) {
		this.mensagem = mensagem;
	}

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	
	/*public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}*/

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Comment [id=" + id + ", descricao=" + descricao + "]";
	}

	

}
