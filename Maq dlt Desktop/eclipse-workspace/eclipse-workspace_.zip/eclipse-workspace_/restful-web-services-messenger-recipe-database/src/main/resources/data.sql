insert into message(id,author,descricao)
values(10001, 'auth1', 'desc1');

insert into message(id,author,descricao)
values(10002, 'auth2', 'desc2');

insert into message(id,author,descricao)
values(10003, 'auth3', 'desc1');

insert into comment(id,author,descricao, mensagem_id)
values(20001, 'comauth1', 'I want to learn AWS', 10001);

insert into comment(id,author,descricao,mensagem_id)
values(20002, 'comauth2', 'I want to learn DevOps', 10001);

insert into comment(id,author,descricao,mensagem_id)
values(20003, 'comauth3', 'I want to Get AWS Certified', 10002);

insert into comment(id,author,descricao,mensagem_id)
values(20004, 'comauth4', 'I want to learn Multi Cloud', 10002);