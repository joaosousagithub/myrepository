package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.Date;
import java.util.List;

import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;

public class Message {
	
	private int id;
	
	@Size(min=2, message="Message should have at least two characters")
	private String message;
	
	@Past(message = "Birthday shoud be in the past") //mas era LocalDate
	private Date created;
	
	private String author;
	
	private List<Comment> comments;
	
	public Message(int id, String message, String author) {
		super();
		this.id = id;
		this.message = message;
		this.created = new Date();
		this.author = author;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getCreated() {
		return created;
	}
	public void setCreated(Date created) {
		this.created = created;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public List<Comment> getComments() {
		return comments;
	}
	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	public Comment getComment(int idComment) {
		int retorno = -1;
		for(int i=0;i<comments.size();i++) {
			if(comments.get(i).getId() == idComment) {
				retorno = i;
				break;
			}
		}
		return comments.get(retorno);
	}
	public void addComment(Comment comment) {
		comments.add(comment);
	}
	public void removeComment(int idComment) {
		for(int i=0;i<comments.size();i++) {
			if(comments.get(i).getId() == idComment) {
				comments.remove(i);
				break;
			}
		}
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", message=" + message + ", author=" + author + "]";
	}
	
	
}
