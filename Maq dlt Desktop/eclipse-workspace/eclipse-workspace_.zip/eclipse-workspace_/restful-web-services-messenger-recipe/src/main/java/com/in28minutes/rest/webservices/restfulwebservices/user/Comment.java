package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.util.Date;

import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Size;

public class Comment {
	
	private int id; 
	
	@Size(min=2, message="Comment should have at least two characters")
	private String message;
	
	private Date created;
	private String author;
	
	public Comment(int id, String message, String author) {
		this.id = id;
		this.message = message;
		this.author = author;
	}

	public long getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Comment [id=" + id + ", message=" + message + "]";
	}

	

}
