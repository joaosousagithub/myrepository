package com.in28minutes.rest.webservices.restfulwebservices.user;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.function.Predicate;
import org.springframework.stereotype.Component;


//@Component
public class UserService {

	private static List<User> users = new ArrayList<>();
	
	private static int usersCount = 10;
	
	static {
		users.add(new User(++usersCount, "Adam", LocalDate.now().minusYears(30)));
		users.add(new User(++usersCount, "Jim", LocalDate.now().minusYears(29)));//adicionei este
		users.add(new User(++usersCount, "Eve", LocalDate.now().minusYears(25)));
		users.add(new User(++usersCount, "Jim", LocalDate.now().minusYears(20)));
		users.add(new User(++usersCount, "Jim", LocalDate.now().minusYears(19)));
		
		List<Post> lstPosts = new ArrayList<>();
		lstPosts.add(new Post(1, "um post"/*, users.get(0)*/));
		lstPosts.add(new Post(2, "um post_b"/*, users.get(0)*/));
		users.get(0).setPosts(lstPosts);
		
		List<Post> lstPosts2 = new ArrayList<>();
		lstPosts2.add(new Post(1, "um post 2"/*, users.get(1)*/));
		users.get(1).setPosts(lstPosts2);
	}
	
	public List<User> findAll(){
		return users;
	}
	
	public User findOne(int id) {
		Predicate<? super User> predicate = user -> user.getId().equals(id);//return users.stream().filter(predicate).findFirst().get();
		return users.stream().filter(predicate).findFirst().orElse(null);
	}
	
	public List<Post> retrieveAllPosts(int id){
		User u = findOne(id);
		return u.getPosts();		
	}
	
	public Post retrievePost(int id, int idPost) {
		User u = findOne(id);
		return u.getPost(idPost);
	}
	
	public User save(User user) {
		user.setId(++usersCount);
		users.add(user);
		return user;
	}
	public void savePost(int id, Post post) {
		User u = findOne(id);
		u.addPost(post);
	}
		
	public void deleteById(int id) {
		Predicate<? super User> predicate = user -> user.getId().equals(id);
		users.removeIf(predicate);
	}
	public void deletePostById(int id, int idPost) {
		User u = findOne(id);
		u.removePost(idPost);
	}
	
	
	
	
	public List<User> getAllMessagesForYear(/*int*/String year){
		List<User> messageForYear = new ArrayList<>();
		//Calendar cal = Calendar.getInstance();
		for(User user/*message*/ : users) {
			//cal.setTime(message.getCreated());
			//if(cal.get(Calendar.YEAR) == year) {
			if(user.getName().compareTo(year) == 0) {
				messageForYear.add(user/*message*/);
			}
			//if(year == message.getId())
			//	messageForYear.add(message);
		}
		return messageForYear;
	}
	public List<User> getAllMessagesPaginated(int start, int size){
		List<User> list = new ArrayList<User>(users);
		if(start + size > list.size()) return new ArrayList<User>();
		return list.subList(start, start + size);
	}
}